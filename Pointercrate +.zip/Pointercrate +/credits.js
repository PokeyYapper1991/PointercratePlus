// @name         Pointercrate + Credits
// @namespace    https://github.com/PokeyYapper1991/PointercratePlus
// @version      1.0
// @description  Credits for Pointercrate +
// @author       PokeyYapper1991
// @match        https://pointercrate.com/*
// @icon   

const credits = '<section class="panel fade js-scroll-anim" id="credits" data-anim="fade"><h2 class="underlined pad clickable">Pointercrate +</h2><h2>PokeyYapper1991</h2><p>Pointercrate + is an extension I made because why not! I am new to this so please reach out through the GitHub and give me any feedback you have!</p><a class="blue hover button" href="https://github.com/PokeyYapper1991/PointercratePlus">Open GitHub Repository</a></section>';

(function () {
    'use strict';

    if (window.location.href.indexOf("https://pointercrate.com/demonlist/") > -1 && window.location.href.indexOf("https://pointercrate.com/demonlist/statsviewer/") === -1) {
        const editorsInsert = document.getElementById("editors");
        let html = credits;
        editorsInsert.insertAdjacentHTML("afterend", html);
    }
}
)()